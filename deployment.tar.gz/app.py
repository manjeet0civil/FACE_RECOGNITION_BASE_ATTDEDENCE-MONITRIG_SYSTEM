import cv2
import os
import shutil
from flask import Flask, request, render_template, jsonify, send_from_directory
from datetime import date, datetime, timedelta
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
import joblib
import base64
import io
from PIL import Image
import traceback
import logging
from flask_cors import CORS
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('attendance_system.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Defining Flask App
app = Flask(__name__, static_folder='frontend/dist', static_url_path='')
CORS(app)  # Enable CORS for all routes

# Saving Date today in 2 different formats
datetoday = date.today().strftime("%m_%d_%y")
datetoday2 = date.today().strftime("%d-%B-%Y")

# Initialize face detector
face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Ensure required directories exist
def ensure_directories():
    directories = ['Attendance', 'Attendance/backups', 'static/faces']
    for directory in directories:
        if not os.path.isdir(directory):
            os.makedirs(directory)
            logger.info(f"Created directory: {directory}")

# Initialize attendance file with header
def initialize_attendance_file():
    filepath = f'Attendance/Attendance-{datetoday}.csv'
    if not os.path.exists(filepath):
        try:
            with open(filepath, 'w') as f:
                f.write('Name,Roll,Time')
            logger.info(f"Created new attendance file: {filepath}")
            # Create backup immediately
            backup_attendance()
        except Exception as e:
            logger.error(f"Error creating attendance file: {e}")
            raise

# Backup attendance file
def backup_attendance():
    try:
        source = f'Attendance/Attendance-{datetoday}.csv'
        if os.path.exists(source):
            backup_dir = 'Attendance/backups'
            timestamp = datetime.now().strftime("%H%M%S")
            backup_file = f'Attendance-{datetoday}-{timestamp}-backup.csv'
            backup_path = os.path.join(backup_dir, backup_file)
            shutil.copy2(source, backup_path)
            
            # Keep only last 5 backups for each day
            cleanup_old_backups()
            logger.info(f"Created backup: {backup_file}")
    except Exception as e:
        logger.error(f"Backup failed: {e}")

# Cleanup old backups
def cleanup_old_backups():
    try:
        backup_dir = 'Attendance/backups'
        files = os.listdir(backup_dir)
        # Group files by date
        files_by_date = {}
        for file in files:
            if file.startswith(f'Attendance-{datetoday}'):
                files_by_date.setdefault(datetoday, []).append(file)
        
        # Keep only last 5 backups for each date
        for date_files in files_by_date.values():
            if len(date_files) > 5:
                date_files.sort()  # Sort by timestamp
                for old_file in date_files[:-5]:  # Remove all but last 5
                    os.remove(os.path.join(backup_dir, old_file))
                    logger.info(f"Removed old backup: {old_file}")
    except Exception as e:
        logger.error(f"Cleanup failed: {e}")

def safe_read_csv(filepath):
    try:
        if os.path.exists(filepath):
            df = pd.read_csv(filepath)
            return df
        return pd.DataFrame(columns=['Name', 'Roll', 'Time'])
    except Exception as e:
        logger.error(f"Error reading CSV {filepath}: {e}")
        return pd.DataFrame(columns=['Name', 'Roll', 'Time'])

def totalreg():
    try:
        total = 0
        faces_dir = 'static/faces'
        if os.path.exists(faces_dir):
            for person_dir in os.listdir(faces_dir):
                person_path = os.path.join(faces_dir, person_dir)
                if os.path.isdir(person_path) and len(os.listdir(person_path)) > 0:
                    total += 1
        return total
    except Exception as e:
        logger.error(f"Error counting registrations: {e}")
        return 0

def extract_faces(img):
    try:
        if isinstance(img, str):  # If image is base64 string
            try:
                # Remove the "data:image/jpeg;base64," part if present
                if ',' in img:
                    img = img.split(',')[1]
                img_data = base64.b64decode(img)
                img = Image.open(io.BytesIO(img_data))
                img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
            except Exception as e:
                logger.error(f"Error decoding image: {e}")
                return []
        
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        face_points = face_detector.detectMultiScale(gray, 1.3, 5)
        return face_points
    except Exception as e:
        logger.error(f"Error extracting faces: {e}")
        return []

def identify_face(facearray):
    try:
        model = joblib.load('static/face_recognition_model.pkl')
        return model.predict(facearray)
    except Exception as e:
        logger.error(f"Error in face identification: {e}")
        raise

def train_model():
    try:
        faces = []
        labels = []
        userlist = os.listdir('static/faces')
        for user in userlist:
            for imgname in os.listdir(f'static/faces/{user}'):
                img = cv2.imread(f'static/faces/{user}/{imgname}')
                if img is None:
                    logger.warning(f"Could not read image: {imgname}")
                    continue
                resized_face = cv2.resize(img, (50, 50))
                faces.append(resized_face.ravel())
                labels.append(user)
        
        if not faces:
            logger.error("No faces found for training")
            raise ValueError("No faces found for training")
            
        faces = np.array(faces)
        knn = KNeighborsClassifier(n_neighbors=5)
        knn.fit(faces,labels)
        joblib.dump(knn,'static/face_recognition_model.pkl')
        logger.info("Model trained successfully")
    except Exception as e:
        logger.error(f"Error training model: {e}")
        raise

def extract_attendance():
    try:
        df = safe_read_csv(f'Attendance/Attendance-{datetoday}.csv')
        # Remove duplicates keeping the latest entry
        df = df.drop_duplicates(subset=['Roll'], keep='last')
        names = df['Name']
        rolls = df['Roll']
        times = df['Time']
        l = len(df)
        return names, rolls, times, l
    except Exception as e:
        logger.error(f"Error extracting attendance: {e}")
        return [], [], [], 0

def add_attendance(name):
    try:
        username = name.split('_')[0]
        userid = name.split('_')[1]
        current_time = datetime.now().strftime("%H:%M:%S")
        
        attendance_file = f'Attendance/Attendance-{datetoday}.csv'
        df = safe_read_csv(attendance_file)
        
        # Check if user already marked attendance today
        if int(userid) not in list(df['Roll']):
            # Create backup before modifying
            backup_attendance()
            
            # Append new attendance
            with open(attendance_file, 'a') as f:
                f.write(f'\n{username},{userid},{current_time}')
            
            logger.info(f"Added attendance for user: {username} ({userid})")
            return True
        return False
    except Exception as e:
        logger.error(f"Error adding attendance: {e}")
        return False

# Initialize directories and files
ensure_directories()
initialize_attendance_file()

################## ROUTING FUNCTIONS #########################

@app.route('/')
def serve():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/attendance/current')
def get_current_attendance():
    try:
        names, rolls, times, l = extract_attendance()
        return jsonify({
            'success': True,
            'attendance': {
                'names': names.tolist(),
                'rolls': rolls.tolist(),
                'times': times.tolist(),
                'length': l
            }
        })
    except Exception as e:
        logger.error(f"Error getting attendance: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/users/total')
def get_total_users():
    try:
        return jsonify({
            'success': True,
            'total': totalreg()
        })
    except Exception as e:
        logger.error(f"Error getting total users: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/attendance/start', methods=['POST'])
def start():
    if 'face_recognition_model.pkl' not in os.listdir('static'):
        return jsonify({
            'success': False,
            'message': 'There is no trained model in the static folder. Please add a new face to continue.'
        })

    try:
        # Get the image data from the request
        image_data = request.json.get('image')
        if not image_data:
            return jsonify({'success': False, 'message': 'No image data received'})

        # Process the image
        faces = extract_faces(image_data)
        if len(faces) == 0:
            return jsonify({'success': False, 'message': 'No face detected'})

        # Get the first face
        (x, y, w, h) = faces[0]
        
        # Convert base64 to image
        img_data = base64.b64decode(image_data.split(',')[1])
        img = Image.open(io.BytesIO(img_data))
        frame = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        
        # Extract and process face
        face = cv2.resize(frame[y:y+h, x:x+w], (50, 50))
        identified_person = identify_face(face.reshape(1, -1))[0]
        
        # Add attendance
        attendance_added = add_attendance(identified_person)
        
        # Get updated attendance
        names, rolls, times, l = extract_attendance()
        
        return jsonify({
            'success': True,
            'person': identified_person,
            'attendance_recorded': attendance_added,
            'attendance': {
                'names': names.tolist(),
                'rolls': rolls.tolist(),
                'times': times.tolist(),
                'length': l
            }
        })

    except Exception as e:
        logger.error(f"Error in start route: {traceback.format_exc()}")
        return jsonify({'success': False, 'message': f'An error occurred: {str(e)}'})

@app.route('/api/users/add', methods=['POST'])
def add():
    try:
        newusername = request.form['newusername']
        newuserid = request.form['newuserid']
        userimagefolder = f'static/faces/{newusername}_{newuserid}'
        
        if not os.path.isdir(userimagefolder):
            os.makedirs(userimagefolder)

        # Process multiple images
        image_count = 0
        for key in request.form:
            if key.startswith('image_'):
                try:
                    # Get the image data
                    image_data = request.form[key]
                    if not image_data:
                        continue

                    # Process and save the image
                    img_data = base64.b64decode(image_data.split(',')[1])
                    img = Image.open(io.BytesIO(img_data))
                    frame = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

                    faces = extract_faces(frame)
                    if len(faces) == 0:
                        continue

                    # Save the face image
                    (x, y, w, h) = faces[0]
                    face_img = frame[y:y+h, x:x+w]
                    
                    # Ensure minimum face size
                    if w < 100 or h < 100:
                        continue
                        
                    # Resize to standard size
                    face_img = cv2.resize(face_img, (200, 200))
                    
                    img_name = f"{newusername}_{image_count}.jpg"
                    cv2.imwrite(os.path.join(userimagefolder, img_name), face_img)
                    image_count += 1
                    logger.info(f"Saved face image {img_name}")
                except Exception as e:
                    logger.warning(f"Failed to process image {key}: {e}")
                    continue

        if image_count == 0:
            shutil.rmtree(userimagefolder)  # Clean up empty directory
            return jsonify({
                'success': False,
                'message': 'No valid face images could be captured. Please try again with better lighting and face position.'
            })

        # Train the model
        train_model()

        # Get updated attendance
        names, rolls, times, l = extract_attendance()
        
        logger.info(f"Successfully added new user: {newusername} with {image_count} images")
        return jsonify({
            'success': True,
            'message': f'User added successfully with {image_count} face images',
            'attendance': {
                'names': names.tolist(),
                'rolls': rolls.tolist(),
                'times': times.tolist(),
                'length': l
            }
        })

    except Exception as e:
        logger.error(f"Error adding new user: {traceback.format_exc()}")
        # Clean up on error
        if os.path.exists(userimagefolder):
            shutil.rmtree(userimagefolder)
        return jsonify({'success': False, 'message': f'Error adding user: {str(e)}'})

if __name__ == '__main__':
    app.run(debug=True, port=5000)